package com.PremierInn.testcases;

import com.PremierInn.base.TestBase;

public class BookingInfoPage extends TestBase {
	
	public void manageBooking(){
	
		click("cancel_Booking_Btn_XPATH");

	/*Alert alert = wait.until(ExpectedConditions.alertIsPresent());
	
	Assert.assertTrue(alert.getText().contains(data.get("alerttext")));
	alert.accept();
	
	Thread.sleep(2000);*/
	}
	
}
