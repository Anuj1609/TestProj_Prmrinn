package com.PremierInn.testcases;

import java.util.Hashtable;
import org.testng.SkipException;
import org.testng.annotations.Test;

import com.PremierInn.base.TestBase;
import com.PremierInn.utilities.TestUtil;

public class PremierInnHomePage extends TestBase {
	
	
	@Test(dataProviderClass=TestUtil.class,dataProvider="dp")
	public void searchCustomerTest(Hashtable<String,String> data) throws InterruptedException{
		
		if(!data.get("runmode").equals("Y")){
			
			throw new SkipException("Skipping the test case as the Run mode for data set is NO");
		}
		
		
		click("manage_Booking_Btn_XPATH");
		type("book_Ref_Field_XPATH",data.get("bookingRef"));
		type("sirname_Field_XPATH",data.get("lastname"));
		
		click("search_Button_XPATH");
		
	}
	
	

}
